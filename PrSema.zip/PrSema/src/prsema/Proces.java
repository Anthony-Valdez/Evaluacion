package prsema;

import static java.lang.Thread.sleep;
import java.awt.Color;
import javax.swing.*;

public class Proces implements Runnable {

    public boolean it;
    public JButton rojo;
    public JButton amarillo;
    public JButton verde;
    public JTextField txt;
    public int cont = 0;

    public Proces(JButton ent1, JButton ent2, JButton ent3, JTextField ent4) {
        this.rojo = ent1;
        this.amarillo = ent2;
        this.verde = ent3;
        this.txt = ent4;
    }

    @Override
    public void run() {
        while (it) {
            cont++;
            //Aqui arranca el color verde
            if (cont >= 1 && cont <= 6) {
                txt.setText(" " + cont);
            }
            if (cont == 1) {
                rojo.setBackground(Color.gray);
                amarillo.setBackground(Color.gray);
                verde.setBackground(Color.green);
            }
            //Aqui arranca el color amarillo
            if (cont >= 6 && cont <= 8) {
                txt.setText(" " + cont);
            }
            if (cont == 6) {
                rojo.setBackground(Color.gray);
                amarillo.setBackground(Color.yellow);
                verde.setBackground(Color.gray);
            }
            //Aqui arranca el color rojo
            if (cont >= 8 && cont <= 13) { 
                txt.setText(" " + cont);
            }
            if (cont == 8) {
                rojo.setBackground(Color.red);
                amarillo.setBackground(Color.gray);
                verde.setBackground(Color.gray);
            }
            if (cont == 13) {
                cont = 0;
            }
            try {
                sleep(1000);
            } catch (Exception e) {
            }
        }
    }

    public void start() {
        it = true;
        new Thread(this).start();
    }

    public void detener() {
        it = false;
    }

    public void reini() {
        cont = 0;
        txt.setText("");
    }
}
